// lu-icon — lucide-style stroke icons as a shadow-DOM custom element.
// <lu-icon name="map" size="16" color="#73726C"></lu-icon>
(function () {
  var P = {
    map: '<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3z"/><path d="M9 3v15"/><path d="M15 6v15"/>',
    'map-pin': '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
    layers: '<path d="m12 2 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M8 12h8M8 16h5"/>',
    activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    'bar-chart': '<path d="M3 21h18"/><rect x="5" y="11" width="3.5" height="7"/><rect x="10.2" y="7" width="3.5" height="11"/><rect x="15.5" y="4" width="3.5" height="14"/>',
    wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94z"/>',
    'check-circle': '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
    'alert-triangle': '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0"/><path d="M12 9v4M12 17h.01"/>',
    'alert-circle': '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5M12 16h.01"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>',
    route: '<circle cx="6" cy="19" r="2.6"/><circle cx="18" cy="5" r="2.6"/><path d="M8.6 19H14a4 4 0 0 0 4-4V7.6"/>',
    siren: '<path d="M7 18v-6a5 5 0 0 1 10 0v6"/><path d="M5 21h14"/><path d="M12 3v2M3.5 10.5H2M22 10.5h-1.5M5.8 5.8 4.6 4.6M18.2 5.8l1.2-1.2"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 21a7 7 0 0 1 14 0"/><path d="M17 5.5a3.5 3.5 0 0 1 0 6.9"/><path d="M18 14.7a6.5 6.5 0 0 1 4 6.3"/>',
    bus: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M3 10h18M8 4v6M16 4v6"/><circle cx="7.5" cy="19" r="1.5"/><circle cx="16.5" cy="19" r="1.5"/>',
    camera: '<path d="M4 8h2.5L8 6h8l1.5 2H20a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1"/><circle cx="12" cy="13" r="3.5"/>',
    gauge: '<path d="M3.5 18a9 9 0 1 1 17 0"/><path d="m14.5 11-3 4.2"/><circle cx="12" cy="17" r="1.3"/>',
    toggle: '<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="17" cy="12" r="2.6"/>',
    'toggle-off': '<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="7" cy="12" r="2.6"/>',
    sliders: '<path d="M3 8h11M18 8h3M3 16h4M11 16h10"/><circle cx="16" cy="8" r="2"/><circle cx="9" cy="16" r="2"/>',
    'trending-up': '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    'trending-down': '<path d="m3 7 6 6 4-4 8 8"/><path d="M21 11v6h-6"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
    'chevron-right': '<path d="m9 6 6 6-6 6"/>',
    'chevron-down': '<path d="m6 9 6 6 6-6"/>',
    'chevron-left': '<path d="m15 6-6 6 6 6"/>',
    'chevron-up': '<path d="m6 15 6-6 6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M3 16v3a2 2 0 0 0 2 2h3"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    'arrow-left': '<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',
    'arrow-right': '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
    play: '<path d="M7 4.5 19 12 7 19.5z"/>',
    pause: '<path d="M8.5 4.5v15M15.5 4.5v15"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.6 2.1"/>',
    download: '<path d="M12 3v12"/><path d="m7 11 5 5 5-5"/><path d="M4 20h16"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',
    send: '<path d="M22 2 11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.4a2.5 2.5 0 1 1 3.4 2.4c-.7.3-1 .9-1 1.6"/><path d="M12 17h.01"/>',
    building: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 7h.01M15 7h.01M9 11h.01M15 11h.01"/><path d="M10 21v-4h4v4"/>',
    cone: '<path d="M12 3 5 20h14z"/><path d="M9.6 12h4.8M8 16h8"/>',
    filter: '<path d="M3 5h18l-7 8v6l-4-2v-4z"/>',
    'more-horizontal': '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
    check: '<path d="m5 13 4 4 10-11"/>',
    'circle-dot': '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.6"/>',
    cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
    database: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><path d="M7 7.5h.01M7 16.5h.01"/>',
    wifi: '<path d="M2 8.5a15 15 0 0 1 20 0"/><path d="M5.5 12.5a10 10 0 0 1 13 0"/><path d="M9 16.5a5 5 0 0 1 6 0"/><path d="M12 20h.01"/>',
    navigation: '<path d="m3 11 19-8-8 19-2.6-8.4z"/>',
    flag: '<path d="M5 21V3h13l-2.6 5 2.6 5H5"/>',
    eye: '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6"/><circle cx="12" cy="12" r="3"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    school: '<path d="m12 3 9 5-9 5-9-5z"/><path d="M6 11v6c0 1.7 2.7 3 6 3s6-1.3 6-3v-6"/>',
    droplets: '<path d="M12 21a5 5 0 0 0 5-5c0-3-5-9-5-9s-5 6-5 9a5 5 0 0 0 5 5"/>',
    car: '<path d="M4 17v-4l2-5h12l2 5v4"/><path d="M4 17h16"/><circle cx="8" cy="18.4" r="1.5"/><circle cx="16" cy="18.4" r="1.5"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.6"/><circle cx="12" cy="12" r="1.2"/>',
    crosshair: '<circle cx="12" cy="12" r="7"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
    broadcast: '<circle cx="12" cy="12" r="2"/><path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 16.2a6 6 0 0 0 0-8.4M4.9 4.9a10 10 0 0 0 0 14.2M19.1 19.1a10 10 0 0 0 0-14.2"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M18.8 5.2l-1.4 1.4M6.6 17.4l-1.4 1.4"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5"/>',
    hardhat: '<path d="M4 16a8 8 0 0 1 16 0"/><rect x="3" y="16" width="18" height="2.6" rx="1"/><path d="M10 9.2V6h4v3.2"/>',
    'corner-right': '<path d="M4 20V9a3 3 0 0 1 3-3h11"/><path d="m15 2 4.5 4L15 10"/>',
    scale: '<path d="M12 3v18M5 7h14"/><path d="M5 7 2.5 14h5zM19 7l-2.5 7h5z"/>',
    ruler: '<rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M7 8v3M12 8v4M17 8v3"/>',
    logout: '<path d="M14 4H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7"/><path d="M17 8l4 4-4 4M21 12H10"/>',
    'external-link': '<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>'
  };
  var FILLED = { play: 1, navigation: 1, zap: 1, filter: 1, send: 1 };
  var LuIcon = function () {};
  LuIcon = class extends HTMLElement {
    static get observedAttributes() { return ['name', 'size', 'color', 'stroke']; }
    connectedCallback() { this.paint(); }
    attributeChangedCallback() { if (this.shadowRoot) this.paint(); }
    paint() {
      if (!this.shadowRoot) this.attachShadow({ mode: 'open' });
      var n = this.getAttribute('name') || 'circle-dot';
      var s = parseFloat(this.getAttribute('size') || '16');
      var c = this.getAttribute('color') || 'currentColor';
      var sw = this.getAttribute('stroke') || '1.7';
      var inner = P[n] || P['circle-dot'];
      var fill = FILLED[n] ? c : 'none';
      var stroke = FILLED[n] ? 'none' : c;
      this.style.display = 'inline-flex';
      this.style.flex = 'none';
      this.style.width = s + 'px';
      this.style.height = s + 'px';
      this.shadowRoot.innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="' + fill +
        '" stroke="' + stroke + '" stroke-width="' + sw + '" stroke-linecap="round" stroke-linejoin="round" style="display:block">' +
        inner + '</svg>';
    }
  };
  if (!customElements.get('lu-icon')) customElements.define('lu-icon', LuIcon);
})();
